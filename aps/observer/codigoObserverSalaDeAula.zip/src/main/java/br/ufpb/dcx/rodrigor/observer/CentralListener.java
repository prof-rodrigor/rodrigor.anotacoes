package br.ufpb.dcx.rodrigor.observer;

public interface CentralListener {
    void novaLigacao(CentralEvent event);
}
