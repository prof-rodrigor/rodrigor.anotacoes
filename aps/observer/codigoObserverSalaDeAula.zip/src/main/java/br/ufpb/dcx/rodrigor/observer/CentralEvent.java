package br.ufpb.dcx.rodrigor.observer;

public class CentralEvent {

    private Sinal sinal;

    private CentralTelefonica source;

    public CentralEvent(CentralTelefonica source, Sinal sinal){
        this.source = source;
        this.sinal = sinal;
    }


    public Sinal getSinal() {
        return sinal;
    }



    public CentralTelefonica getSource() {
        return source;
    }


}
