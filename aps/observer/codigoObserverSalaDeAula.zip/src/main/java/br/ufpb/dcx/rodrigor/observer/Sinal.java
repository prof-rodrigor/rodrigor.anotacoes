package br.ufpb.dcx.rodrigor.observer;

public enum Sinal {

    DADOS, VOZ;
}
