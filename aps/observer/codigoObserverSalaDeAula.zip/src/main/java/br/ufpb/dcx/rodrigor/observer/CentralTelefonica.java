package br.ufpb.dcx.rodrigor.observer;

import java.util.ArrayList;
import java.util.List;

public class CentralTelefonica {



    private String id;
    private List<CentralListener> listeners = new ArrayList<>();

    public CentralTelefonica(String id){
        this.id = id;
    }

    public void novaLigacao(Sinal sinal){
        // (...)
        CentralEvent event = new CentralEvent(this,sinal);
        for(CentralListener fone : listeners)
            fone.novaLigacao(event);

    }

    public static void main(String[] args) {
        CentralTelefonica central1 = new CentralTelefonica("001");

        Telefone fone = new Telefone();

        central1.addCentralListener(fone);
        central1.addCentralListener(new Fax());

        CentralTelefonica central2 = new CentralTelefonica("002");
        central2.addCentralListener(fone);

        central1.novaLigacao(Sinal.VOZ);
        central2.novaLigacao(Sinal.VOZ);
    }

    public void addCentralListener(CentralListener listener){
        this.listeners.add(listener);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
