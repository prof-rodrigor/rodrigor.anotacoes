package br.ufpb.dcx.rodrigor.observer;

public class Fax implements CentralListener{

    public void receberDados(){
        System.out.println("recebendo dados...");
    }

    @Override
    public void novaLigacao(CentralEvent event) {
        if(event.getSinal().equals(Sinal.DADOS)){
            System.out.println("Fonte da ligação: "+event.getSource().getId());
            this.receberDados();
        }

    }
}
