package br.ufpb.dcx.rodrigor.observer;

public class Telefone implements CentralListener{

    public void tocar(){
        System.out.println("triiiimmm");
    }

    @Override
    public void novaLigacao(CentralEvent event) {
        if(event.getSinal().equals(Sinal.VOZ)) {
            System.out.println("Fonte da ligação: "+event.getSource().getId());
            this.tocar();
        }
    }
}
